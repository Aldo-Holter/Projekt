<?php 
	session_start();

	function choose_most_liked(){
		$max;

		$servername = "localhost";
    	$username = "root";
   	 	$password = "password";
    	$dbname = "login";
    	//ovaranje konekcije
    	$conn = new mysqli($servername, $username, $password, $dbname);
		// Provjera uspjesnosti spajanja na bazu
    	if ($conn->connect_error) {
        	die("Uspostavljanje konekcije na bazu nije uspjelo: ". $conn->connect_error);
    	}
    	$sql = "SELECT SongId, filename FROM Audios ORDER BY likes DESC LIMIT 1";
   		$stmt = $conn->prepare($sql);
    	$stmt->execute();
    	$result = $stmt->get_result();

    	$max = $result->fetch_assoc();
    	return $max["filename"];
	}

	function currently_playing(){
		$name = choose_most_liked();
		print_r("Currently playing: " . $name);
		echo "<br>";
		print_r("<audio autoplay controls onended ='my_function()'>
			<source src = $name type = 'audio/mpeg'>
			</source>
			</audio>");
	}

	function audio_ended(){
		$message = "Iskoristili ste svoje pravo glasa";
			echo "<script type='text/javascript'>alert('$message');</script>";
		
	}
?>





<html>
<head>

	<title>Jewbox</title>
	<link rel="stylesheet" type="text/css" href="style.css">




</head>
<body>
 
<script>
function myFunction() {
  alert("The video has ended");
}
</script>

	<div style="float:right">
		<form align="right" name="form1" method="post" action="login.php">
		  <label>
		  <input name="submit2" type="submit" id="submit2" value="Izlaz">
		  </label>
		</form>
	</div>

	<h1>DOBRODOSLI NA JUKEBOX</h1>
	


	<div id ="frm1">
		
		<?php
	    $servername = "localhost";
    	$username = "root";
   	 	$password = "password";
    	$dbname = "login";
    	
    	 // Stvaranje konekcije na bazu
    	if($_SESSION["pravo_glasa"]){
    		
    		echo  " Imate pravo glasa!";
    		echo '</br>'; 
    	}else{
    		$message = "Iskoristili ste svoje pravo glasa";
			echo "<script type='text/javascript'>alert('$message');</script>";
    		echo "Nemate pravo glasa ( nazad u kuhinju )";
    	}

    $conn = new mysqli($servername, $username, $password, $dbname);

    // Provjera uspjesnosti spajanja na bazu
    if ($conn->connect_error) {
        die("Uspostavljanje konekcije na bazu nije uspjelo: ". $conn->connect_error);
    } 

    $sql = "SELECT filename, likes, SongId FROM Audios";
    $stmt = $conn->prepare($sql);
    $stmt->execute();
    $result = $stmt->get_result();

    //  Provjera ima li rezultata
    if ($result->num_rows > 0) {
        echo "<table  align ='center'><tr><th>filename</th><th colspan = '2'>likes</th></tr>";
        // Printanje rezultata
        while($row = $result->fetch_assoc()) {
            echo "<tr>";
            echo "<td>" . $row["filename"]. "</td>";
            echo "<td>" . $row["likes"]. "</td>";
            echo "<td> <a href='Like.php?Song=".$row["SongId"]."'> <img src='/vjezba/thumbs.jpeg' width='30' height='30' /> </a></td>";
            echo "</tr>";
        
        }
    } else {
        echo "Nema rezultata";
    }
    currently_playing();
    //slika koja ne radi
    //$path = '/vjezba/thumbs.jpeg';
    //echo ' <img src="/vjezba/thumbs.jpeg" width="30" height="30" />';
    //  Zatvaranje konekcije
    $stmt->close();
    	?>

		
	</div>
</body>
</html>

