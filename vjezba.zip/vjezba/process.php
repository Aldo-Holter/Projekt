<?php
//start session
	session_start();
//get values from login.php file
	$username = $_POST['user'];
	$password = $_POST['pass'];

	$_SESSION["user"] = $username;
	$_SESSION["pass"] = $password;
	$_SESSION["pravo_glasa"] = 1;
	if($username == NULL || $password == NULL) header("Location: http://localhost/vjezba/login.php");
	//connect to the database and select database
	$link = mysqli_connect("localhost", "root", "password", "login");
	if(!$link){
		die("ne mogu se spojiti na MySQL posluzitelj" . mysqli_connect_error());
	}

	
	//Query the database for user
	$result = mysqli_query($link, "select * from users where username = '$username' and password = '$password' ") ;
	if(!$result){
		die("Pogreska kod izvodenja SQL upita. " );
	}
	//reading from database
	$row = mysqli_fetch_array($result);
	$hit = 0;
	//pretrazi cijelu bazu korisnika 
	while($row != NULL){
		
		if(($row['username'] == $username) && ($row['password'] == $password)){
			session_start();
			$_SESSION['username'] = $username;
			//ako je admin
			if($username == "root")
			header("Location: http://localhost/vjezba/jukebox.php");
			//ako je korisnik ( obicni)
			else
			header("Location: http://localhost/vjezba/jukeboxuser.php");

			mysqli_free_result($result);
			$hit = 1;
		}
		
		
	$row = mysqli_fetch_array($result);	
	}
	//ako se ne nade korisnik u bazi, vrati na login stranicu
	if(!$hit)
		header("Location: http://localhost/vjezba/login.php");

	mysqli_close($link);
?>