<?php 
session_start();
 ?>

<html>
<head>
	<title>Jukebox</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
		<div style="float:right">
		<form align="right" name="form1" method="post" action="login.php">
		  <label>
		  <input name="submit2" type="submit" id="submit2" value="log out">
		  </label>
		</form>
	</div>
	<h1 >DOBRODOSLI NA JUKEBOX</h1>

	<div id ="frm1">
		<b id="b">ubacite mp3 file za jukebox playlist<b><br>

		<br>

		<?php
	    $servername = "localhost";
    	$username = "root";
   	 	$password = "password";
    	$dbname = "login";
    
    	 // Stvaranje konekcije na bazu
    

    $conn = new mysqli($servername, $username, $password, $dbname);

    // Provjera uspjesnosti spajanja na bazu
    if ($conn->connect_error) {
        die("Uspostavljanje konekcije na bazu nije uspjelo: ". $conn->connect_error);
    } 

    $sql = "SELECT filename, likes, SongId FROM Audios";
    $stmt = $conn->prepare($sql);
    $stmt->execute();
    $result = $stmt->get_result();

    //  Provjera ima li rezultata
    if ($result->num_rows > 0) {
        echo "<table  align = 'center'><tr><th>filename</th><th>likes</th><th></th></tr>";
        // Printanje rezultata
        while($row = $result->fetch_assoc()) {
            echo "<tr>";
            $ime  = substr($row["filename"] , 8, -4);

            echo "<td>" . $ime . "</td>";
            echo "<td>" . $row["likes"]. "</td>";
            echo "<td><a href='Delete.php?Song=".$row["SongId"]."'><img src='/vjezba/deletebut.jpg' width='30' height='30' /></a></td>";
            echo "</tr>";
        }
    } else {
        echo "Nema rezultata";
    }

    //  Zatvaranje konekcije
    $stmt->close();

    	
    	?>


		<form action="upload.php" method="POST" enctype="multipart/form-data">
		<input type="file" name="audioFile" id = "f"/>
		<input type="submit" value="Upload Audio" name ="save_audio" id = "a"/>
		</form>


	</div>
		<br>	<br>	<br>	<br>
	 
</body>
</html>

