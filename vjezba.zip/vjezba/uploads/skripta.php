Pozdrav <?php echo $_POST["ime"]; ?>!<br/>
Ti si takav <?php echo $_POST["posao"]; ?>.
