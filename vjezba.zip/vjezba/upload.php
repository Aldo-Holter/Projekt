<?php
if(isset($_POST['save_audio']) && $_POST['save_audio']=="Upload Audio"){

	$dir='uploads/';
	$audio_path = $dir.basename($_FILES['audioFile']['name']);
	
	echo $_FILES['audioFile']['error'];
	echo 'ovdje sam';
	
	if(move_uploaded_file($_FILES['audioFile']['tmp_name'], $audio_path)){
		echo 'uploaded success';
		saveAudio($audio_path);
	}

}
function saveAudio($fileName){
	$conn=mysqli_connect('localhost', 'root', 'password' ,'login');

	if(!$conn)
		echo "server not conencted";


	$query ="insert into Audios(filename)values('{$fileName}')";
	$r = mysqli_query($conn, $query);

	if(!$r)
		echo "mysql query no correct";
	else
		echo "uploaded sucessfully onto phpmyadmin";
	mysqli_close($conn);
	header('Location: jukebox.php');
}


?>