<?php

    session_start();
    $servername = "localhost";
    $username = "root";
    $password = "password";
    $dbname = "login";

    // Stvaranje konekcije na bazu
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Provjera uspjesnosti spajanja na bazu
    if ($conn->connect_error) {
        die("Uspostavljanje konekcije na bazu nije uspjelo: ". $conn->connect_error);
    }

    if($_SESSION["pravo_glasa"]){







    $sql_query = $conn->prepare("SELECT likes FROM Audios WHERE SongId = ?");

    $sql_query->bind_param('s', $_GET["Song"]);
    $sql_query->execute();
    $result = $sql_query->get_result();

    $row = $result->fetch_assoc();
    $novi = $row["likes"] + 1;
    echo $novi;

    $sql_query = $conn->prepare("UPDATE Audios SET likes = $novi WHERE SongId = ?");
    $sql_query->bind_param('s', $_GET["Song"]);
    $sql_query->execute();

    $sql_query->close();
    $_SESSION["pravo_glasa"] = 0;    
    }else{
        header('Location: jukeboxuser.php');    
    }
    
    header('Location: jukeboxuser.php');
?>